/*
 * SCORM 1.2 API Wrapper — CAE Teacher CPD
 * Robust ADL-standard discovery: scans frame parents, window.top, and the
 * opener window (every probe is cross-origin-safe). Retries on a short timer
 * to survive popup launches where the LMS attaches the API after the SCO loads.
 * Falls back to standalone demo mode only after discovery genuinely fails.
 */

const SCORM = (() => {
  let api = null;
  let initialized = false;
  let standalone = false;
  const store = {};

  // Read win.API without throwing on cross-origin windows.
  function safeAPI(win) {
    try {
      if (win && win.API) return win.API;
      // SCORM 2004 fallback, just in case the LMS presents that object name.
      if (win && win.API_1484_11) return win.API_1484_11;
    } catch (e) { /* cross-origin — ignore */ }
    return null;
  }

  // Walk up a window's parent chain looking for the API.
  function scanFrames(win) {
    let attempts = 0;
    try {
      while (win && !safeAPI(win) && win.parent && win.parent !== win && attempts < 10) {
        win = win.parent;
        attempts++;
      }
    } catch (e) { /* cross-origin — stop walking */ }
    return safeAPI(win);
  }

  // Full ADL getAPI(): this window's frames, then top, then the opener's frames.
  function findAPI() {
    let found = scanFrames(window);
    if (!found) { try { found = safeAPI(window.top); } catch (e) {} }
    if (!found) {
      try {
        if (window.opener && typeof window.opener !== 'undefined') {
          found = scanFrames(window.opener);
        }
      } catch (e) { /* cross-origin opener — ignore */ }
    }
    return found || null;
  }

  function tryInit() {
    api = findAPI();
    if (!api) return false;
    const result = api.LMSInitialize('');
    initialized = result === 'true' || result === true;
    if (!initialized) {
      console.warn('[SCORM] API found but LMSInitialize failed:', api.LMSGetLastError && api.LMSGetLastError());
    } else {
      console.info('[SCORM] LMS API connected — tracking enabled.');
    }
    return initialized;
  }

  // Retry for ~3s: the popup player may attach window.API after the SCO loads.
  function init() {
    if (tryInit()) { hideBanner(); return true; }

    let tries = 0;
    const maxTries = 15;          // 15 x 200ms = 3 seconds
    const timer = setInterval(function () {
      tries++;
      if (tryInit()) {
        clearInterval(timer);
        hideBanner();
      } else if (tries >= maxTries) {
        clearInterval(timer);
        standalone = true;
        console.info('[SCORM] No LMS API found after retries — running in standalone/demo mode.');
        showBanner();
      }
    }, 200);
    return false;
  }

  function showBanner() {
    const b = document.getElementById('scorm-demo-banner');
    if (b) b.style.display = 'block';
  }
  function hideBanner() {
    const b = document.getElementById('scorm-demo-banner');
    if (b) b.style.display = 'none';
  }

  function setValue(element, value) {
    store[element] = value;
    if (standalone) return true;
    if (!initialized) return false;
    const result = api.LMSSetValue(element, value);
    if (result !== 'true' && result !== true) {
      console.warn('[SCORM] LMSSetValue(' + element + ') failed:', api.LMSGetLastError && api.LMSGetLastError());
    }
    return result === 'true' || result === true;
  }

  function getValue(element) {
    if (standalone) return store[element] || '';
    if (!initialized) return '';
    return api.LMSGetValue(element);
  }

  function commit() {
    if (standalone) return true;
    if (!initialized) return false;
    return api.LMSCommit('') === 'true';
  }

  function finish() {
    if (standalone) return true;
    if (!initialized) return false;
    const result = api.LMSFinish('');
    initialized = false;
    return result === 'true';
  }

  function setScore(raw, min, max) {
    setValue('cmi.core.score.raw', raw);
    setValue('cmi.core.score.min', min !== undefined ? min : 0);
    setValue('cmi.core.score.max', max !== undefined ? max : 100);
    commit();
  }

  function setCompletion(status) {
    setValue('cmi.core.lesson_status', status);
    commit();
  }

  function setSessionTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const fmt = String(h).padStart(4, '0') + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    setValue('cmi.core.session_time', fmt);
  }

  return { init, setValue, getValue, commit, finish, setScore, setCompletion, setSessionTime, isStandalone: function(){ return standalone; } };
})();

window.addEventListener('load', function(){ SCORM.init(); });
window.addEventListener('beforeunload', function(){ SCORM.finish(); });
